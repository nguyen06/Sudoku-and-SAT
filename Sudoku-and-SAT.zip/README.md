# Sudoku-and-SAT
Project for CSC 320 with Professor Bruce Kapron