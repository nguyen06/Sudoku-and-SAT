import re
f = open('out.cnf', 'r')

f.readline()
numbers = " " + f.readline()
li = []
li = re.findall(' \d+',numbers)

li2 = []
counter = 0
for i in li:
	li[counter] = i[1:]
	counter += 1
li.pop()
print len(li)

x = int(li[0])
print x	

i = x / 81
i = i
x = x % 81
print ("x is " + str(x))
j = x / 9
j = j
x = x % 9
print ("x is " + str(x))

k = x

i = i + 1
j = j + 1
k = k + 2
print i
print j
print k


